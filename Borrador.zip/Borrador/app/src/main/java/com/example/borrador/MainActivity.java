package com.example.borrador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.lang.reflect.Array;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    ArrayList <arraylists> lista = new ArrayList<arraylists>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button boton=(Button) findViewById(R.id.button);
        lista.add(new arraylists(4.636404559796773,-74.08373344648129,"1"));
        lista.add(new arraylists(4.635666692168087,-74.08373344648129,"2"));
        lista.add(new arraylists(4.635329839242644,-74.08289916830648,"3"));
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intento=new Intent(getApplicationContext(),MapsActivity.class);
                intento.putExtra("cordenadas",lista);
                startActivity(intento);
            }
        });
    }
}
