package com.example.borrador;

import androidx.fragment.app.FragmentActivity;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.*;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MapsActivity<lugares> extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    Intent intento=getIntent();

    ArrayList<arraylists> lugares=new ArrayList<arraylists>();
    lugares = (ArrayList<arraylists>)getIntent().getSerializableExtra("QuestionListExtra");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
       /* mMap = googleMap;
        LatLng a1=new LatLng(4.636404559796773,-74.08373344648129);
        Marker a=mMap.addMarker(new MarkerOptions().position(a1).title("Marker in la Nacho"));
        LatLng b1=new LatLng(4.635666692168087,-74.08301450329569);
        Marker b=mMap.addMarker(new MarkerOptions().position(b1).title("Marker in la Nacho"));
        LatLng c1=new LatLng(4.635329839242644,-74.08289916830648);
        Marker c=mMap.addMarker(new MarkerOptions().position(c1).title("Marker in la Nacho"));*/

        mMap = googleMap;

        /*lugares.add(new LatLng(4.637862702334999,-74.08292440664117));
        lugares.add(new LatLng(4.636404559796773,-74.08373344648129));
        lugares.add(new LatLng(4.635666692168087,-74.08301450329569));
        lugares.add(new LatLng(4.635329839242644,-74.08289916830648));
        lugares.add(new LatLng(4.635420796834211,-74.08253700911179));*/
        // Add a marker in Sydney and move the camera
        //ArrayList<Marker> marcadores= new ArrayList<Marker>();
        for (int i=0;i<lugares.size();i++){

            /*LatLng pos=new LatLng(lugares.get(i)[0],lugares.get(i)[1]);*/
            mMap.addMarker(new MarkerOptions().position(lugares.get(i)).title("Marker in la Nacho"));
            mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    Intent intento=new Intent(getApplicationContext(),ventana.class);
                    startActivity(intento);
                    return true;
                }
            });
        }
        /*mMap.moveCamera(CameraUpdateFactory.newLatLng(pos));

        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));*/
    }
}
