package com.example.borrador;
import com.google.android.gms.maps.model.LatLng;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
public class chaza extends AppCompatActivity{
    LatLng pos ;
    String Nombre;
    public chaza(Float lat, Float lang, String nombre){
        pos=new LatLng(lat,lang);
        Nombre=nombre;
    }
    public void creaperfil(){
        Intent intento =new Intent(getApplicationContext(),Main2Activity.class);
        intento.putExtra("Nombre",Nombre);
        startActivity(intento);
    }


}
