package com.example.prueba;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
public class Adaptador extends BaseAdapter{
    Context contexto;
    int layout;
    ArrayList<productoTemporal> listaprod;
    Adaptador(Context context,int layout,ArrayList<productoTemporal> productos){
        this.contexto = context;
        this.layout = layout;
        this.listaprod = productos;
    }
    @Override
    public int getCount() {
        return this.listaprod.size();
    }

    @Override
    public Object getItem(int position) {
        return this.listaprod.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View vista= convertView;
        LayoutInflater inflador = LayoutInflater.from(this.contexto);
        vista=inflador.inflate(R.layout.item_lista,null);

        TextView nombreprod=(TextView) vista.findViewById(R.id.titulo);
        TextView descripcionprod=(TextView) vista.findViewById(R.id.descripcion);
        TextView Precio=(TextView) vista.findViewById(R.id.Precio);

        productoTemporal productoactual = listaprod.get(position);
        nombreprod.setText(productoactual.getNombre());
        descripcionprod.setText(productoactual.getDescripcion());
        Precio.setText(productoactual.getPrecio()+"");
        return vista;
    }
}
