package com.example.prueba;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Categoria extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String seleccion="";
    String finale;//Esta es la variable importante, el string a partir del cual se hace la busqueda
    String[] elementos={"Comida","Micelania","Accesorios"};
    String[] comida={"Almuerzo","Mecato","Postres","Panaderia"};
    String[] micelania={"Papaeleria","Electronica","Articulos varios","Otra cosa"};
    String[] accesorios={"Bisuteria","Ropa","Parches","Meh"};
    CheckBox caja1;CheckBox caja2;
    CheckBox caja3;CheckBox caja4;
    Spinner tipo1;
    ArrayList<CheckBox> cajas=new ArrayList<CheckBox>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categoria);
        Button boton=(Button) findViewById(R.id.btn_4_selCat) ;

        tipo1=(Spinner) findViewById(R.id.spn_4_selector);
        tipo1.setOnItemSelectedListener(this);
        ArrayAdapter<String> adaptador=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,elementos);
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tipo1.setAdapter(adaptador);
        caja1=(CheckBox) findViewById(R.id.chb_4_1);
        caja1.setVisibility(View.INVISIBLE);
        caja2=(CheckBox) findViewById(R.id.chb_4_2);
        caja2.setVisibility(View.INVISIBLE);
        caja3=(CheckBox) findViewById(R.id.chb_4_3);
        caja3.setVisibility(View.INVISIBLE);
        caja4=(CheckBox) findViewById(R.id.chb_4_4);
        caja4.setVisibility(View.INVISIBLE);
        cajas.add(caja1);
        cajas.add(caja2);
        cajas.add(caja3);
        cajas.add(caja4);
        for (int i=0;i<cajas.size();i++){
            final int seleccion=i;
            cajas.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for(int x=0;x<cajas.size();x++){
                        cajas.get(x).setChecked(false);//ESTO ES PARA QUE DESCHEQUEE TODAS LAS CAJAS QUE ESTEN CHEQUEADAS
                    }
                    cajas.get(seleccion).setChecked(true);
                    finale = cajas.get(seleccion).getText().toString();
                    Toast.makeText(getApplicationContext(), finale, Toast.LENGTH_SHORT).show();
                    iniciarRegistro(finale);
                }
            });
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        seleccion = tipo1.getSelectedItem().toString();
        for(int x=0;x<cajas.size();x++){
            cajas.get(x).setChecked(false);//ESTO ES PARA QUE DESCHEQUEE TODAS LAS CAJAS QUE ESTEN CHEQUEADAS
        }
        if(seleccion.equals(elementos[0])){
            this.mostrar(comida);
        }
        if(seleccion.equals(elementos[1])){
            this.mostrar(micelania);
        }
        if(seleccion.equals(elementos[2])){
            this.mostrar(accesorios);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }//Es para que muestre solamente las cajas que si tienen algo adentro
    public void mostrar(String[] lista){
        for (int i=0; i<cajas.size();i++){
            try{
                cajas.get(i).setVisibility(View.VISIBLE);
                cajas.get(i).setText(lista[i]);
            }
            catch (Exception e){
                cajas.get(i).setVisibility(View.INVISIBLE);
            }
        }
    }
    private void iniciarRegistro(String finale) {
        Intent intent = new Intent(Categoria.this, Registro.class);
        intent.putExtra("Categoria",finale);
        startActivity(intent);
    }
}