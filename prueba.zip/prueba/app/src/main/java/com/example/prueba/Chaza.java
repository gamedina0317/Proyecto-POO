package com.example.prueba;

public class Chaza {

    private String Descripcion;
    private String Anotacion;
    private String Nombre;
    private float Latitud;
    private float Longitud;

    public float getLatitud() {
        return Latitud;
    }

    public void setLatitud(float latitud) {Latitud = latitud;}

    public float getLongitud() {return Longitud;}

    public void setLongitud(float longitud) {
        Longitud = longitud;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getAnotacion() {
        return Anotacion;
    }

    public void setAnotacion(String anotacion) {
        Anotacion = anotacion;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }
}
