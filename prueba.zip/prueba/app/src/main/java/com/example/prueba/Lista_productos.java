package com.example.prueba;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class Lista_productos extends AppCompatActivity {

    protected String Id, Categoria;
    boolean tipo;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference ref = database.getReference();

        recuperacionParametros();

        final ArrayList<productoTemporal> lista = new ArrayList<productoTemporal>();
        listarDatos(ref,lista);

        Adaptador miadaptador = new Adaptador(this, R.layout.item_lista,lista);
        ListView listView=(ListView) findViewById(R.id.lista);
        listView.setAdapter(miadaptador);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                productoTemporal seleccionado = lista.get(position);
                Intent intento=new Intent(getApplicationContext(),perfilProducto.class);
                intento.putExtra("nombre",  seleccionado.getNombre());
                intento.putExtra("descripcion",  seleccionado.getDescripcion());
                intento.putExtra("precio",  seleccionado.getPrecio()+"");
                intento.putExtra("cantidad",  seleccionado.getCantidad()+"");
                intento.putExtra("URL", seleccionado.getURL());
                startActivity(intento);
            }
        });
        /*ArrayList<String> lista=new ArrayList<String>();
        ArrayAdapter<String> adaptador=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lista);
        ListView listView=(ListView) findViewById(R.id.lista);*/

    }

    private void recuperacionParametros() {
            Intent intento = getIntent();
            tipo = intento.getBooleanExtra("estado",false);
            Id = intento.getStringExtra("ID");
            Categoria = intento.getStringExtra("Categoria");
        }

    private void listarDatos(DatabaseReference ref, final ArrayList<productoTemporal> listica) {
        ref.child(Categoria).child(Id).child("Productos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot objSnapshot : dataSnapshot.getChildren()){
                    productoTemporal prod = objSnapshot.getValue(productoTemporal.class);
                    listica.add(prod);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }
}
