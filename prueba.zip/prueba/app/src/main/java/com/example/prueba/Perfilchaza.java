package com.example.prueba;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Perfilchaza extends AppCompatActivity {

    private FirebaseAuth mAuth;

    private boolean tipo;
    private String Id, Categoria;
    private Button btn_Datos, btn_Ubicacion, btn_Productos, btn_cerrarSesion;
    private TextView txt_nombre;
    private EditText txt_descripcion, txt_anotaciones;
    private String anotaciones, descripcion, nombre;
    private float latitud, longitud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfilchaza);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference ref = database.getReference();
        mAuth = FirebaseAuth.getInstance();

        recuperacionParametros();

        btn_Datos = (Button) findViewById(R.id.btn_5_datos);
        btn_Ubicacion = (Button) findViewById(R.id.btn_5_ubicacion);
        btn_Productos = (Button) findViewById(R.id.btn_5_productos);
        btn_cerrarSesion = (Button) findViewById(R.id.btn_5_cerrarSesion);
        txt_nombre = (TextView) findViewById(R.id.txt_5_nombre);
        txt_descripcion = (EditText) findViewById(R.id.txt_5_descripcion);
        txt_anotaciones = (EditText) findViewById(R.id.txt_5_anotaciones);

        recuperacionDatos(ref);

        if (tipo){//true cuando se es cliente
            btn_Datos.setVisibility(View.INVISIBLE);
            btn_Ubicacion.setVisibility(View.INVISIBLE);
            btn_Productos.setVisibility(View.INVISIBLE);
            btn_cerrarSesion.setVisibility(View.INVISIBLE);
        }
        else{ //false
            btn_Datos.setVisibility(View.VISIBLE);
            btn_Ubicacion.setVisibility(View.VISIBLE);
            btn_Productos.setVisibility(View.VISIBLE);
            btn_cerrarSesion.setVisibility(View.VISIBLE);

            btn_Ubicacion.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ArrayList<arraylists> lista = new ArrayList<arraylists>();
                    lista.add(new arraylists(latitud,longitud,Id));//Esta coordenada es de prueba, encontrar como obtener estos datos de la base de datos
                    Intent intento = new Intent(Perfilchaza.this, Mapa.class);
                    intento.putExtra("estado",false);
                    intento.putExtra("cordenadas",lista);
                    startActivity(intento);
                }
            });
        }

        btn_Datos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String editAnotaciones = txt_anotaciones.getText().toString();
                String editDescripcion = txt_descripcion.getText().toString();
                ref.child(Categoria).child(Id).child("Anotacion").setValue(editAnotaciones);
                ref.child(Categoria).child(Id).child("Descripcion").setValue(editDescripcion);
                recuperacionDatos(ref);
            }
        });

        btn_Productos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Perfilchaza.this, Lista_productos.class);
                intent.putExtra("estado",false);
                intent.putExtra("ID",Id);
                intent.putExtra("Categoria",Categoria);
                startActivity(intent);
            }
        });

        btn_cerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent = new Intent(Perfilchaza.this,inicio.class);
                startActivity(intent);
            }
        });
    }

    private void recuperacionDatos(DatabaseReference ref) {
        ref.child(Categoria).child(Id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Chaza chaz = dataSnapshot.getValue(Chaza.class);
                anotaciones = chaz.getAnotacion();
                descripcion = chaz.getDescripcion();
                nombre = chaz.getNombre();
                latitud = chaz.getLatitud();
                longitud = chaz.getLongitud();
                txt_anotaciones.setText(anotaciones);
                txt_descripcion.setText(descripcion);
                txt_nombre.setText(nombre);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    private void recuperacionParametros() {
        Intent intento = getIntent();
        tipo = intento.getBooleanExtra("estado",false);
        Id = intento.getStringExtra("ID");
        Categoria = intento.getStringExtra("Categoria");
    }
}
