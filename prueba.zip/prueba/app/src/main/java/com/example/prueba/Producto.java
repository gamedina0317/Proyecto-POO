package com.example.prueba;
import java.io.Serializable;
public class Producto {

    private String Nombre, Descripcion, URL, Cantidad, Precio;

    //Constructores
    public Producto(String nombre, String descripcion, String URL, String cantidad, String precio) {
        Nombre = nombre;
        Descripcion = descripcion;
        this.URL = URL;
        Cantidad = cantidad;
        Precio = precio;
    }

    public Producto() {
    }

    //Metodos
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getCantidad() {
        return Cantidad;
    }

    public void setCantidad(String cantidad) {
        Cantidad = cantidad;
    }

    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String precio) {
        Precio = precio;
    }
}
