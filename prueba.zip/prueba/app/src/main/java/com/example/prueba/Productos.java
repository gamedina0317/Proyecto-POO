package com.example.prueba;
import java.io.Serializable;
public class Productos implements Serializable{
    String nombre_producto;
    String descripcion;
    String precio;
    String cantidad;
    public Productos(String nom,String des,String preci,String cant){
        nombre_producto=nom;
        descripcion=des;
        precio=preci;
        cantidad=cant;
    }
    public String getNombre(){
        return nombre_producto;
    }
    public void setNombre(String Nombre){this.nombre_producto=Nombre;}

    public String getDescripcion(){
        return nombre_producto;
    }
    public void setDescripcion(String Descripcion){ this.descripcion=Descripcion;}

    public String getPrecio(){ return precio; }
    public void setPrecio(String Precio){this.precio=Precio;}

    public String getCantidad(){
        return cantidad;
    }
    public void setCantidad(String Cantidad){this.cantidad=Cantidad;}
}
