package com.example.prueba;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class edicionProductos extends AppCompatActivity {
    String Nombre;
    String Descripcion;
    String Precio;
    String Cantidad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edicion_productos);
        Intent intento=getIntent();
        final Productos elProducto=(Productos) intento.getSerializableExtra("objeto");

        final EditText textNom=(EditText) findViewById(R.id.edit_nombre);
        textNom.setText(intento.getStringExtra("nombre")+"");


        final EditText textDes=(EditText) findViewById(R.id.edit_descripcion);
        textDes.setText(intento.getStringExtra("descripcion"+""));

        final EditText textPrec=(EditText) findViewById(R.id.edit_precio);
        textPrec.setText(intento.getStringExtra("precio"+""));

        final EditText textCant=(EditText) findViewById(R.id.edit_cant);
        textCant.setText(intento.getStringExtra("cantidad"+""));

        Button guardar=(Button) findViewById(R.id.edit_formulario);
        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                elProducto.setNombre(textNom.getText()+"");
                elProducto.setDescripcion(textDes.getText()+"");
                elProducto.setPrecio(textPrec.getText()+"");
                elProducto.setCantidad(textCant.getText()+"");
                Intent Intento=new Intent(getApplicationContext(),perfilProducto.class);
                Intento.putExtra("nombre",  textNom.getText()+"");
                Intento.putExtra("descripcion",  textDes.getText()+"");
                Intento.putExtra("precio",  textPrec.getText()+"");
                Intento.putExtra("cantidad",  textCant.getText()+"");
                Intento.putExtra("objeto",elProducto);
                startActivity(Intento);
            }
        });

    }
}
