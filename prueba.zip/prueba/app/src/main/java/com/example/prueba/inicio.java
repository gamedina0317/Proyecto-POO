package com.example.prueba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class inicio extends AppCompatActivity {

    Button btn_chacero, btn_cliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        btn_chacero = (Button) findViewById(R.id.btn_1_chacero);
        btn_chacero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarlogin();
            }
        });
    }

    private void iniciarlogin() {
        Intent intent = new Intent(inicio.this, login.class);
        startActivity(intent);
    }
}
