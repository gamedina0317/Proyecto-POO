package com.example.prueba;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class perfilProducto extends AppCompatActivity {
    String Nombre;
    String Descripcion;
    String Precio;
    String Cantidad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_producto);

        Intent intento=getIntent();
        final Productos elProducto=(Productos) intento.getSerializableExtra("objeto");
        Nombre= intento.getStringExtra("nombre");
        Descripcion=intento.getStringExtra("descripcion");
        Precio=intento.getStringExtra("precio");
        Cantidad=intento.getStringExtra("cantidad");
        TextView elnombre=(TextView) findViewById(R.id.nombProdu) ;
        elnombre.setText("Producto: "+Nombre);

        TextView ladescripcion=(TextView) findViewById(R.id.descrip) ;
        ladescripcion.setText("Descripcion: "+Descripcion);

        TextView elprecio=(TextView) findViewById(R.id.precioPro) ;
        elprecio.setText("Precio: "+ Precio);

        TextView lacantidad=(TextView) findViewById(R.id.cantidadDis) ;
        lacantidad.setText("Existencias: " + Cantidad);


        Button volverlista =(Button) findViewById(R.id.botonListProduc);
        volverlista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Lista_productos.class));
            }
        });
    }
}
